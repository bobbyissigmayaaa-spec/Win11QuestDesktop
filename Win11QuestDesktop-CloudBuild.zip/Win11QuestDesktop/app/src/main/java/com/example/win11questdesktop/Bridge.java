package com.example.win11questdesktop;

import android.app.Activity;
import android.content.Intent;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.StatFs;
import android.provider.Settings;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;

public class Bridge {
    private final Activity a;
    Bridge(Activity a) { this.a = a; }

    private boolean allAccess() {
        if (Build.VERSION.SDK_INT >= 30) return Environment.isExternalStorageManager();
        return a.checkSelfPermission("android.permission.READ_EXTERNAL_STORAGE") == 0;
    }
    private void cp(File s, File d) throws IOException {
        if (s.isDirectory()) {
            d.mkdirs();
            File[] c = s.listFiles();
            if (c != null) for (File f : c) cp(f, new File(d, f.getName()));
        } else {
            try (InputStream i = new FileInputStream(s); OutputStream o = new FileOutputStream(d)) {
                byte[] b = new byte[65536]; int n;
                while ((n = i.read(b)) > 0) o.write(b, 0, n);
            }
        }
    }
    private boolean rm(File f) {
        if (f.isDirectory()) { File[] c = f.listFiles(); if (c != null) for (File x : c) rm(x); }
        return f.delete();
    }

    @JavascriptInterface public String roots() {
        try {
            JSONObject o = new JSONObject();
            File app = a.getExternalFilesDir(null);
            o.put("app", app == null ? a.getFilesDir().getAbsolutePath() : app.getAbsolutePath());
            o.put("shared", Environment.getExternalStorageDirectory().getAbsolutePath());
            o.put("all", allAccess());
            return o.toString();
        } catch (Exception e) { return "{}"; }
    }
    @JavascriptInterface public boolean hasAll() { return allAccess(); }
    @JavascriptInterface public void reqAll() {
        a.runOnUiThread(() -> {
            try {
                a.startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:" + a.getPackageName())));
            } catch (Exception e) {
                try { a.startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)); }
                catch (Exception e2) {
                    a.requestPermissions(new String[]{"android.permission.READ_EXTERNAL_STORAGE",
                            "android.permission.WRITE_EXTERNAL_STORAGE"}, 1);
                }
            }
        });
    }
    @JavascriptInterface public String list(String p) {
        File[] fs = new File(p).listFiles();
        if (fs == null) return "null";
        JSONArray r = new JSONArray();
        for (File f : fs) {
            try {
                JSONObject o = new JSONObject();
                o.put("n", f.getName()); o.put("d", f.isDirectory());
                o.put("s", f.length()); o.put("m", f.lastModified());
                r.put(o);
            } catch (Exception ignored) {}
        }
        return r.toString();
    }
    @JavascriptInterface public String readText(String p) {
        try (InputStream i = new FileInputStream(p)) {
            ByteArrayOutputStream o = new ByteArrayOutputStream();
            byte[] b = new byte[16384]; int n, t = 0;
            while ((n = i.read(b)) > 0 && t < 1048576) { o.write(b, 0, n); t += n; }
            return o.toString("UTF-8");
        } catch (Exception e) { return ""; }
    }
    @JavascriptInterface public String readB64(String p) {
        try {
            File f = new File(p);
            if (f.length() > 8L * 1024 * 1024) return "";
            byte[] b = new byte[(int) f.length()];
            try (DataInputStream i = new DataInputStream(new FileInputStream(f))) { i.readFully(b); }
            return Base64.encodeToString(b, Base64.NO_WRAP);
        } catch (Exception e) { return ""; }
    }
    @JavascriptInterface public String writeText(String p, String t) {
        try (OutputStream o = new FileOutputStream(p)) { o.write(t.getBytes("UTF-8")); return "ok"; }
        catch (Exception e) { return String.valueOf(e.getMessage()); }
    }
    @JavascriptInterface public String writeB64(String p, String b64) {
        try (OutputStream o = new FileOutputStream(p)) { o.write(Base64.decode(b64, Base64.DEFAULT)); return "ok"; }
        catch (Exception e) { return String.valueOf(e.getMessage()); }
    }
    @JavascriptInterface public String mkdir(String p) { return new File(p).mkdirs() ? "ok" : "Could not create folder"; }
    @JavascriptInterface public String del(String p) { return rm(new File(p)) ? "ok" : "Could not delete"; }
    @JavascriptInterface public String rename(String f, String t) { return new File(f).renameTo(new File(t)) ? "ok" : "Could not rename"; }
    @JavascriptInterface public String copy(String f, String t) {
        try { cp(new File(f), new File(t)); return "ok"; } catch (Exception e) { return String.valueOf(e.getMessage()); }
    }
    @JavascriptInterface public String move(String f, String t) {
        File s = new File(f), d = new File(t);
        if (s.renameTo(d)) return "ok";
        try { cp(s, d); rm(s); return "ok"; } catch (Exception e) { return String.valueOf(e.getMessage()); }
    }
    @JavascriptInterface public String storage() {
        try {
            StatFs s = new StatFs(Environment.getExternalStorageDirectory().getAbsolutePath());
            return s.getTotalBytes() + "," + s.getAvailableBytes();
        } catch (Exception e) { return "0,0"; }
    }
    @JavascriptInterface public String info() {
        return Build.MANUFACTURER + " " + Build.MODEL + "|Android " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")|" + Build.DISPLAY;
    }
    @JavascriptInterface public int getVolume() {
        AudioManager m = (AudioManager) a.getSystemService("audio");
        return m.getStreamVolume(AudioManager.STREAM_MUSIC) * 100 / Math.max(1, m.getStreamMaxVolume(AudioManager.STREAM_MUSIC));
    }
    @JavascriptInterface public void setVolume(int pct) {
        AudioManager m = (AudioManager) a.getSystemService("audio");
        m.setStreamVolume(AudioManager.STREAM_MUSIC, Math.round(m.getStreamMaxVolume(AudioManager.STREAM_MUSIC) * pct / 100f), 0);
    }
    @JavascriptInterface public void sys(String which) {
        String act = Settings.ACTION_SETTINGS;
        if (which.equals("wifi")) act = Settings.ACTION_WIFI_SETTINGS;
        else if (which.equals("bt")) act = Settings.ACTION_BLUETOOTH_SETTINGS;
        else if (which.equals("display")) act = Settings.ACTION_DISPLAY_SETTINGS;
        else if (which.equals("sound")) act = Settings.ACTION_SOUND_SETTINGS;
        final String fa = act;
        a.runOnUiThread(() -> { try { a.startActivity(new Intent(fa)); } catch (Exception ignored) {} });
    }
}
